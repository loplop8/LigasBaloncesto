
package controladores.rest;
/**
 *
 * @author Zatonio
 */
import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;


@ApplicationPath("Rest")
public class ApplicationConfig extends Application {
    
}
